 <section class="poper-footer">
        <div class="footer">
            <div class="footer-bb">
                <ul>
                    <li><a href="#"><i class="far fa-newspaper"></i><p>News</p></a></li>
                    <li><a href="#"><i class="fas fa-video"></i><p>Videos</p></a></li>
                    <li><a href="#"><i class="fas fa-camera-retro"></i><p>Photos</p></a></li>
                    <li><a href="#"><i class="far fa-newspaper"></i><p>News Beeps</p></a></li>
                    <li><a href="#"><i class="fas fa-ellipsis-h"></i></i></a></li>
                </ul>
            </div>
        </div>
    </section>